import React, { useState, useEffect } from 'react';
import DarkBackground from './shared/DarkBackground';
import ServiceSelect from './booking/ServiceSelect';
import WhatsAppButton from './booking/WhatsAppButton';
import BookingButton from './booking/BookingButton';
import FormField from './booking/FormField';
import { useBooking } from '../context/BookingContext';
import { useFormValidation } from './booking/useFormValidation';
import { FormData } from '../types/booking';

const initialFormData: FormData = {
  name: '',
  phone: '',
  email: '',
  service: '',
  date: '',
  time: '',
  requirements: ''
};

export default function BookingForm() {
  const { selectedService } = useBooking();
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const { errors, setErrors, touchedFields, setTouchedFields, validateField, validateForm } = useFormValidation();

  useEffect(() => {
    if (selectedService) {
      setFormData(prev => ({ ...prev, service: selectedService }));
    }
  }, [selectedService]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const newData = { ...prev, [name]: value };
      const error = validateField(name as keyof FormData, value, newData);
      setErrors(prev => ({ ...prev, [name]: error }));
      return newData;
    });
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name } = e.target;
    setTouchedFields(prev => new Set(prev).add(name as keyof FormData));
    const error = validateField(name as keyof FormData, formData[name as keyof FormData], formData);
    setErrors(prev => ({ ...prev, [name]: error }));
  };

  // Form is valid if there are no errors and at least one contact method is provided
  const hasValidEmail = formData.email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email);
  const hasValidPhone = formData.phone && /^\+?[\d\s-]+$/.test(formData.phone);
  const isValid = Object.keys(errors).length === 0 && (hasValidEmail || hasValidPhone);

  return (
    <section id="booking" className="relative pt-20">
      <DarkBackground className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="font-cormorant text-4xl text-center text-white mb-12">Book Your Session</h2>
          
          <form className="bg-white/95 backdrop-blur-sm rounded-lg shadow-lg p-8">
            <div className="grid md:grid-cols-2 gap-6">
              <FormField
                label="Name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                onBlur={handleBlur}
                error={touchedFields.has('name') ? errors.name : undefined}
              />
              
              <FormField
                label="Phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleChange}
                onBlur={handleBlur}
                error={touchedFields.has('phone') ? errors.phone : undefined}
              />
              
              <FormField
                label="Email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                onBlur={handleBlur}
                error={touchedFields.has('email') ? errors.email : undefined}
              />
              
              <ServiceSelect
                value={formData.service}
                onChange={handleChange}
                onBlur={handleBlur}
              />
              
              <FormField
                label="Preferred Date"
                name="date"
                type="date"
                value={formData.date}
                onChange={handleChange}
                onBlur={handleBlur}
                error={touchedFields.has('date') ? errors.date : undefined}
              />
              
              <FormField
                label="Preferred Time"
                name="time"
                type="time"
                value={formData.time}
                onChange={handleChange}
                onBlur={handleBlur}
                error={touchedFields.has('time') ? errors.time : undefined}
              />
            </div>
            
            <div className="mt-6">
              <label className="block text-brand-dark mb-2" htmlFor="requirements">
                Special Requirements
              </label>
              <textarea
                id="requirements"
                name="requirements"
                rows={4}
                className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-brand-primary focus:ring-1 focus:ring-brand-primary outline-none"
                value={formData.requirements}
                onChange={handleChange}
                onBlur={handleBlur}
              />
            </div>
            
            <div className="mt-8 flex flex-col md:flex-row gap-4 justify-between items-center">
              <BookingButton 
                formData={formData} 
                isValid={isValid}
                errors={errors}
              />
              <WhatsAppButton formData={formData} />
            </div>
          </form>
        </div>
      </DarkBackground>
    </section>
  );
}